// import 'package:js/js.dart';
// import 'package:latlong2/latlong.dart';
//
// @JS('initMap')
// external void initMap();
//
// @JS('setMapCenter')
// external void setMapCenter(double lat, double lng);
//
// @JS('addPolyline')
// external void addPolyline(List<LatLng> coordinates);
//
// @JS('addMarker')
// external void addMarker(double lat, double lng);
